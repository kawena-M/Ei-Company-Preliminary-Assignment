export interface Coffee {    
     cost(): number;    
    description(): string;
}
