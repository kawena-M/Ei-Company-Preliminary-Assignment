export class OldSystem {     oldRequest(): void {
    console.log('Old system request');
}
}
