export class NewSystem {     newRequest(): void {
    console.log('New system request');     }
}