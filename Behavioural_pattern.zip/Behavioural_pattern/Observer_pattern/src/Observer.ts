export interface Observer {
    update(news: string): void;
   }